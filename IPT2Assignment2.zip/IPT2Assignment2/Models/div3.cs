﻿namespace IPT2Assignment2.Models
{
    public class div3
    {
        public float num { get; set; }
    }
}
