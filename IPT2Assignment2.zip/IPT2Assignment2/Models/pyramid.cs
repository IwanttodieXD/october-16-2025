﻿namespace IPT2Assignment2.Models
{
    public class pyramid
    {
        public int rows { get; set; }
    }
}
